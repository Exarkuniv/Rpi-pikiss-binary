#!/bin/bash
cd $HOME/games/captain_s
./captain

