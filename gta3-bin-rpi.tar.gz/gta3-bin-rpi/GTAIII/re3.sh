#!/bin/bash

check_required_files() {
    readonly FILE_PATH="files_required.txt"
    [[ ! -e $FILE_PATH ]] && return 0

    readarray -t ARRAY < <(cut -d, -f1 $FILE_PATH)
    for FILE in "${ARRAY[@]}"; do
        if [[ ! -e $FILE ]]; then
            echo "The file/directory $FILE is missing."
            read -p "Press a KEY to exit..."
            exit 1
        fi
    done

    [[ -e $FILE_PATH ]] && rm "$FILE_PATH"
}

run() {
    if [ "$(getconf LONG_BIT)" == "64" ]; then
        ./re3_arm64
    else
        ./re3
    fi
}

check_required_files
run

