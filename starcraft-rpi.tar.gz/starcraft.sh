#!/bin/bash
LD_LIBRARY_PATH=. setarch linux32 -L wine libscr_sa_arm.exe.so

