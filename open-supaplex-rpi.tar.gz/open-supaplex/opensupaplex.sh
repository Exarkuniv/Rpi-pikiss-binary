#!/bin/sh
# Clean audio buffer
aconnect -x

./opensupaplex
