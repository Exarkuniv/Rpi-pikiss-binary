#!/bin/bash

check_required_files() {
    readonly FILE_PATH="files_required.txt"
    [[ ! -e $FILE_PATH ]] && return 0

    readarray -t ARRAY < <(cut -d, -f1 $FILE_PATH)
    for FILE in "${ARRAY[@]}"; do
        if [[ ! -e $FILE ]]; then
            echo "The file $FILE is missing."
            read -p "Press a KEY to exit..."
            exit 1
        fi
    done

    [[ -e $FILE_PATH ]] && rm "$FILE_PATH"
}

run() {
    cd "$(dirname "$0")" || exit 1
    VGA="HDMI-1"
    RESOLUTION=800x600 && off=107
    python - << EOF&
import gtk
def create_window():
    window = gtk.Window()
    window.set_title('sc_bg')
    window.set_default_size(200, 200)
    window.connect('destroy', gtk.main_quit)
    color = gtk.gdk.color_parse(str('#000000'))
    window.modify_bg(gtk.STATE_NORMAL, color)
    window.set_decorated(False)
    window.show()
    window.move(-30, -30)
    window.resize(2590, 1470)
create_window()
gtk.main()
EOF
    echo $! > /tmp/sc_bg.pid
    sleep 0.3
    xrandr --output "$VGA" --mode "$RESOLUTION" --panning "$RESOLUTION" --transform 1.33333333,0,-$off,0,1,0,0,0,1
    LD_LIBRARY_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf LIBGL_DRIVERS_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf/dri/ GBM_DRIVERS_PATH=/home/pi/mesa/lib setarch linux32 -L /usr/lib/wine/wine libd2game_sa_arm.exe.so
    xrandr --output "$VGA" --auto --panning 0x0 --scale 1x1

    if [[ -e /tmp/sc_bg.pid ]]; then
        kill `cat /tmp/sc_bg.pid`
        rm /tmp/sc_bg.pid
    fi
}

check_required_files
run

