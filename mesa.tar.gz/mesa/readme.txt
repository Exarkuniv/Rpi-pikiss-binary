Hi this was compiled by PI LAB

the are many ways to use this mesa
you can use it from command line 
like this

LD_LIBRARY_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf/  LIBGL_DRIVERS_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf/dri GBM_DRIVERS_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf/ yourgame


or use the example of glxinfo to make a simple script for an specific game

or to edit shortcuts and add those
lines..one example would be (before the execution lines of the game start.sh or run.sh or whatever...)

export 	LD_LIBRARY_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf/ 
export	LIBGL_DRIVERS_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf/dri 
export	GBM_DRIVERS_PATH=/home/pi/mesa/lib/arm-linux-gnueabihf/ 